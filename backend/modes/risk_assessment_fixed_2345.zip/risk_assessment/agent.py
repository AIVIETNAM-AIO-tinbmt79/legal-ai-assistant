
from __future__ import annotations

import json
import os
import re
from typing import Any
from urllib.parse import urlparse

from openai import OpenAI
from pydantic import ValidationError

from .legal_tools import legal_search
from .prompts import (
    AGENT_1_SYSTEM_PROMPT,
    AGENT_2_SYSTEM_PROMPT,
    AGENT_3_SYSTEM_PROMPT,
    build_agent3_prompt,
    build_batch_prompt,
)
from .schemas import (
    Agent3Decision,
    AgentAnalysisResult,
    ContractChunk,
    LegalReference,
    LegalSearchRequest,
    LegalSearchResult,
    MergedRiskCandidate,
    RiskCandidate,
    VerifiedRisk,
)
from config.settings import Settings


setting = Settings()

FPT_BASE_URL = setting.LLM_BASE_URL
FPT_API_KEY = setting.API_LLM
FPT_MODEL = setting.LLM_MODEL

MAX_AGENT3_TOOL_CALLS_PER_ISSUE = max(
    1,
    int(os.getenv("MAX_AGENT3_TOOL_CALLS_PER_ISSUE", "2")),
)

ALLOWED_LEGAL_DOMAINS = [
    "chinhphu.vn",
    "thuvienphapluat.vn",
]

_client: OpenAI | None = None


# ============================================================
# LLM CONFIGURATION
# ============================================================

def get_llm_client() -> OpenAI:
    """Khởi tạo OpenAI-compatible client dùng API của FPT."""

    global _client

    if _client is None:
        if not FPT_API_KEY:
            raise RuntimeError(
                "Chưa cấu hình LLM_API_KEY trong biến môi trường."
            )

        _client = OpenAI(
            api_key=FPT_API_KEY,
            base_url=FPT_BASE_URL,
        )

    return _client


def call_llm(
    system_prompt: str,
    user_prompt: str,
) -> str:
    """Gọi LLM và trả về nội dung văn bản."""

    response = get_llm_client().chat.completions.create(
        model=FPT_MODEL,
        temperature=0,
        messages=[
            {
                "role": "system",
                "content": system_prompt,
            },
            {
                "role": "user",
                "content": user_prompt,
            },
        ],
    )

    content = response.choices[0].message.content

    if not content:
        raise ValueError("LLM trả về nội dung rỗng.")

    return content.strip()


# ============================================================
# JSON PARSING
# ============================================================

def parse_json(text: str) -> dict[str, Any]:
    """Đọc JSON do LLM trả về, kể cả khi có Markdown code fence."""

    text = (text or "").strip()

    text = re.sub(
        r"^\s*```(?:json)?\s*",
        "",
        text,
        flags=re.IGNORECASE,
    )

    text = re.sub(r"\s*```\s*$", "", text)

    try:
        data = json.loads(text)

    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")

        if start < 0 or end < start:
            raise ValueError(
                "LLM không trả về JSON object hợp lệ."
            )

        data = json.loads(text[start:end + 1])

    if not isinstance(data, dict):
        raise ValueError(
            "JSON do LLM trả về phải là một object."
        )

    return data


# ============================================================
# CONTRACT CHUNK FORMATTING
# ============================================================

def _format_batch(
    batch: list[ContractChunk],
) -> str:
    """Định dạng các chunk để đưa vào prompt."""

    parts = []

    for chunk in batch:
        parts.append(
            f"""
CHUNK_ID: {chunk.id}
HIERARCHY: {chunk.hierarchy_path or ""}
ARTICLE: {chunk.article or ""}
CLAUSE: {chunk.clause or ""}
POINT: {chunk.point or ""}
CHUNK_TYPE: {chunk.chunk_type}

CONTENT:
{chunk.text}
""".strip()
        )

    return "\n\n---\n\n".join(parts)


def _chunk_lookup(
    chunks: list[ContractChunk],
) -> dict[str, ContractChunk]:
    """Tạo bảng tra cứu chunk theo ID."""

    return {chunk.id: chunk for chunk in chunks}


# ============================================================
# AGENT 1 AND AGENT 2
# ============================================================

def _run_detection_agent(
    batches: list[list[ContractChunk]],
    agent_name: str,
    system_prompt: str,
) -> list[AgentAnalysisResult]:
    """
    Chạy một agent phát hiện rủi ro độc lập.

    Agent chỉ phát hiện ứng viên, không kết luận vi phạm pháp luật.
    """

    results: list[AgentAnalysisResult] = []

    for index, batch in enumerate(batches, start=1):
        if not batch:
            continue

        # Chỉ chấp nhận ID thuộc batch đang được gửi cho LLM.
        # Không dùng ID của batch khác để tránh gắn nhầm rủi ro.
        batch_chunk_ids = {chunk.id for chunk in batch}

        prompt = build_batch_prompt(
            agent_name,
            _format_batch(batch),
        )

        raw = call_llm(system_prompt, prompt)
        data = parse_json(raw)

        raw_risks = data.get("risks", [])

        if not isinstance(raw_risks, list):
            raise ValueError(
                f"{agent_name}, batch_{index}: "
                "trường 'risks' phải là một danh sách."
            )

        risks: list[RiskCandidate] = []

        for item in raw_risks:
            if not isinstance(item, dict):
                continue

            try:
                risk = RiskCandidate.model_validate(item)

            except ValidationError:
                continue

            if risk.chunk_id not in batch_chunk_ids:
                continue

            risks.append(risk)

        results.append(
            AgentAnalysisResult(
                agent=agent_name,
                batch_id=f"batch_{index}",
                risks=risks,
            )
        )

    return results


def run_agent_1(
    batches: list[list[ContractChunk]],
) -> list[AgentAnalysisResult]:
    """Agent 1 phát hiện các ứng viên rủi ro."""

    return _run_detection_agent(
        batches=batches,
        agent_name="agent_1",
        system_prompt=AGENT_1_SYSTEM_PROMPT,
    )


def run_agent_2(
    batches: list[list[ContractChunk]],
) -> list[AgentAnalysisResult]:
    """Agent 2 kiểm tra hợp đồng độc lập với Agent 1."""

    return _run_detection_agent(
        batches=batches,
        agent_name="agent_2",
        system_prompt=AGENT_2_SYSTEM_PROMPT,
    )


# ============================================================
# MERGE CANDIDATES
# ============================================================

def _normalize_text(value: str) -> str:
    """Chuẩn hóa văn bản để so sánh các ứng viên."""

    return re.sub(
        r"\s+",
        " ",
        value or "",
    ).strip().lower()


def merge_agent_results(
    agent_1_results: list[AgentAnalysisResult],
    agent_2_results: list[AgentAnalysisResult],
) -> list[MergedRiskCandidate]:
    """
    Gộp các ứng viên cùng loại và cùng chunk.

    Không yêu cầu cả hai agent cùng phát hiện một rủi ro.
    Agent 3 sẽ xác minh bằng căn cứ pháp luật.
    """

    groups: dict[
        tuple[str, str],
        list[tuple[str, RiskCandidate]],
    ] = {}

    for result in agent_1_results:
        for risk in result.risks:
            key = (
                risk.chunk_id,
                _normalize_text(risk.risk_type),
            )

            groups.setdefault(key, []).append(
                ("agent_1", risk)
            )

    for result in agent_2_results:
        for risk in result.risks:
            key = (
                risk.chunk_id,
                _normalize_text(risk.risk_type),
            )

            groups.setdefault(key, []).append(
                ("agent_2", risk)
            )

    severity_rank = {
        "low": 1,
        "medium": 2,
        "high": 3,
    }

    candidates: list[MergedRiskCandidate] = []

    for index, entries in enumerate(
        groups.values(),
        start=1,
    ):
        _, primary = max(
            entries,
            key=lambda entry: severity_rank[
                entry[1].severity
            ],
        )

        reasons = list(
            dict.fromkeys(
                risk.reason.strip()
                for _, risk in entries
                if risk.reason and risk.reason.strip()
            )
        )

        descriptions = list(
            dict.fromkeys(
                risk.description.strip()
                for _, risk in entries
                if risk.description
                and risk.description.strip()
            )
        )

        detected_by = sorted(
            {
                agent_name
                for agent_name, _ in entries
            }
        )

        legal_question = (
            f"Quy định pháp luật hiện hành nào điều chỉnh "
            f"vấn đề '{primary.risk_type}' trong điều khoản này? "
            "Cần kiểm tra điều khoản có mâu thuẫn trực tiếp với "
            "quy định bắt buộc áp dụng hay không."
        )

        candidates.append(
            MergedRiskCandidate(
                candidate_id=f"candidate_{index:04d}",
                risk_type=primary.risk_type,
                description=(
                    descriptions[0]
                    if descriptions
                    else primary.description
                ),
                related_chunk_ids=[primary.chunk_id],
                severity=primary.severity,
                reasons=reasons,
                detected_by=detected_by,
                legal_question=legal_question,
            )
        )

    return candidates


# ============================================================
# AGENT 3 HELPERS
# ============================================================

def normalize_agent3_decision(
    data: dict[str, Any],
    candidate: MergedRiskCandidate,
) -> dict[str, Any]:
    """Chuẩn hóa output của Agent 3 trước khi kiểm tra schema."""

    data = dict(data)

    if not data.get("evidence_type"):
        data["evidence_type"] = "insufficient"

    if not data.get("confidence"):
        data["confidence"] = "low"

    if data.get("action") == "search_legal":
        request = data.get("search_request")

        if not isinstance(request, dict):
            request = {}

        query = request.get("query")

        if not isinstance(query, str) or not query.strip():
            request["query"] = candidate.legal_question

        # Luôn giới hạn domain theo cấu hình hệ thống.
        request["allowed_domains"] = (
            ALLOWED_LEGAL_DOMAINS.copy()
        )

        # Dùng đúng tên trường trong LegalSearchRequest.
        max_results = request.get("max_results", 3)

        if (
            isinstance(max_results, bool)
            or not isinstance(max_results, int)
        ):
            max_results = 3

        request["max_results"] = max(
            1,
            min(max_results, 10),
        )

        data["search_request"] = request

    else:
        data["search_request"] = None

    return data


def _format_previous_search(
    references: list[LegalReference],
) -> str:
    """Định dạng các kết quả tìm kiếm trước đó."""

    if not references:
        return (
            "Chưa thu thập được căn cứ pháp luật phù hợp từ "
            "lần tìm kiếm trước. Không được coi việc không tìm thấy "
            "tài liệu là bằng chứng điều khoản hợp pháp hoặc trái luật."
        )

    return "\n\n".join(
        (
            f"TIÊU ĐỀ: {ref.title}\n"
            f"URL: {ref.url}\n"
            f"NỘI DUNG: {ref.content or ref.snippet}"
        )
        for ref in references
    )


def _record_trace(
    trace: list[dict[str, Any]] | None,
    *,
    step: int,
    decision: Agent3Decision,
    candidate: MergedRiskCandidate,
    references_found: int,
) -> None:
    """Ghi lại quyết định của Agent 3."""

    if trace is None:
        return

    trace.append(
        {
            "step": step,
            "action": decision.action,
            "reasoning": decision.reasoning,
            "candidate_id": candidate.candidate_id,
            "tool_query": (
                decision.search_request.query
                if decision.search_request
                else None
            ),
            "references_found": references_found,
        }
    )


# ============================================================
# AGENT 3: LEGAL VERIFICATION
# ============================================================

def _normalize_search_query(query: str) -> str:
    """Chuẩn hóa truy vấn để nhận diện truy vấn lặp."""
    query = (query or "").casefold()
    query = re.sub(r"[^\w\s]", " ", query, flags=re.UNICODE)
    return re.sub(r"\s+", " ", query).strip()


def _usable_legal_references(
    references: list[LegalReference],
) -> list[LegalReference]:
    """Chỉ giữ nguồn đúng domain, URL hợp lệ và có nội dung đủ dùng."""
    usable: list[LegalReference] = []
    seen_urls: set[str] = set()

    for ref in references:
        if not _is_allowed_legal_url(ref.url):
            continue
        content = (ref.content or "").strip()
        if len(content) < 100:
            continue

        parsed = urlparse(ref.url)
        canonical_url = (
            f"{parsed.scheme.lower()}://{(parsed.hostname or '').lower()}"
            f"{parsed.path.rstrip('/')}"
        )
        if canonical_url in seen_urls:
            continue
        seen_urls.add(canonical_url)
        usable.append(ref.model_copy(update={"content": content}))

    return usable[: max(3, MAX_AGENT3_TOOL_CALLS_PER_ISSUE * 3)]


def _merge_legal_references(
    existing: list[LegalReference],
    incoming: list[LegalReference],
) -> list[LegalReference]:
    """Gộp kết quả nhiều lượt, giữ nguồn hợp lệ và không trùng URL."""
    # Ưu tiên nguồn mới nhất trong prompt, đồng thời giữ nguồn tốt từ lượt trước.
    return _usable_legal_references([*incoming, *existing])


def run_agent_3_issue(
    candidate: MergedRiskCandidate,
    contract_chunks: list[ContractChunk],
    trace: list[dict[str, Any]] | None = None,
) -> VerifiedRisk | None:
    """Xác minh một ứng viên bằng tìm kiếm có giới hạn và kiểm tra bằng chứng."""
    chunk_ids = set(candidate.related_chunk_ids)
    relevant_chunks = [chunk for chunk in contract_chunks if chunk.id in chunk_ids]
    if not relevant_chunks:
        return None

    references: list[LegalReference] = []
    previous_reasoning = ""
    search_attempts = 0
    seen_queries: set[str] = set()
    search_was_attempted = False

    # Có thêm lượt LLM để phản hồi truy vấn trùng hoặc quyết định keep yếu,
    # nhưng số lần gọi công cụ vẫn bị chặn bởi MAX_AGENT3_TOOL_CALLS_PER_ISSUE.
    max_steps = MAX_AGENT3_TOOL_CALLS_PER_ISSUE * 2 + 3

    for step in range(max_steps):
        prompt = build_agent3_prompt(
            issue=candidate,
            contract_chunks=relevant_chunks,
            legal_references=references,
            previous_reasoning=previous_reasoning,
        )
        if seen_queries:
            prompt += (
                "\n\nTRUY VẤN ĐÃ THỰC HIỆN (không lặp lại):\n"
                + "\n".join(f"- {q}" for q in sorted(seen_queries))
                + "\nNếu cần tìm tiếp, hãy đưa ra truy vấn khác biệt có mục tiêu cụ thể."
            )
        if search_was_attempted and not references:
            prompt += (
                "\n\nLƯU Ý: Các lượt tìm kiếm trước chưa thu được nguồn đủ nội dung. "
                "Không được coi đây là bằng chứng hợp đồng hợp pháp hoặc trái luật."
            )

        raw = call_llm(AGENT_3_SYSTEM_PROMPT, prompt)
        decision_data = normalize_agent3_decision(parse_json(raw), candidate)
        try:
            decision = Agent3Decision.model_validate(decision_data)
        except ValidationError as exc:
            previous_reasoning += f"\nOutput Agent 3 không hợp lệ theo schema: {exc}"
            continue

        previous_reasoning = decision.reasoning
        _record_trace(
            trace,
            step=step + 1,
            decision=decision,
            candidate=candidate,
            references_found=len(references),
        )

        if decision.action == "search_legal":
            request = decision.search_request
            if request is None:
                if trace:
                    trace[-1]["action"] = "search_legal_skipped_invalid_request"
                previous_reasoning += "\nThiếu search_request hợp lệ; hãy tạo truy vấn cụ thể hoặc drop."
                continue

            normalized_query = _normalize_search_query(request.query)
            if not normalized_query:
                if trace:
                    trace[-1]["action"] = "search_legal_skipped_empty_query"
                previous_reasoning += "\nTruy vấn rỗng; hãy tạo truy vấn cụ thể hoặc drop."
                continue

            if normalized_query in seen_queries:
                if trace:
                    trace[-1]["action"] = "search_legal_skipped_duplicate"
                previous_reasoning += (
                    f"\nĐã từ chối gọi công cụ vì truy vấn bị lặp: {request.query!r}. "
                    "Hãy dùng truy vấn khác có mục tiêu mới hoặc drop."
                )
                continue

            if search_attempts >= MAX_AGENT3_TOOL_CALLS_PER_ISSUE:
                if trace:
                    trace[-1]["action"] = "search_legal_skipped_limit"
                previous_reasoning += (
                    "\nĐã hết lượt tìm kiếm pháp luật. Không được gọi công cụ thêm; "
                    "hãy kết luận thận trọng dựa trên bằng chứng hiện có hoặc drop."
                )
                continue

            seen_queries.add(normalized_query)
            search_attempts += 1
            search_was_attempted = True
            try:
                tool_result: LegalSearchResult = legal_search(request)
                references = _merge_legal_references(
                    references,
                    [ref for ref in tool_result.references if _is_allowed_legal_url(ref.url)],
                )
                if tool_result.errors:
                    previous_reasoning += "\nLỗi tìm kiếm: " + "; ".join(tool_result.errors)
            except Exception as exc:
                previous_reasoning += (
                    f"\nCông cụ tìm kiếm gặp lỗi {type(exc).__name__}. "
                    "Không lặp lại truy vấn này; nếu còn lượt hãy tìm theo hướng khác."
                )

            if trace:
                trace[-1]["references_found"] = len(references)
            continue

        if decision.action in {"drop", "final"}:
            return None

        if decision.action == "keep":
            usable_references = _usable_legal_references(references)
            rejection_reasons = []
            if not usable_references:
                rejection_reasons.append("không có nguồn cho phép với content tối thiểu 100 ký tự")
            if decision.evidence_type != "direct_contradictory":
                rejection_reasons.append("evidence_type không phải direct_contradictory")
            if not decision.analysis.strip():
                rejection_reasons.append("thiếu phân tích đối chiếu cụ thể")
            if not decision.conclusion.strip():
                rejection_reasons.append("thiếu kết luận cụ thể")
            if decision.confidence not in {"medium", "high"}:
                rejection_reasons.append("độ tin cậy thấp")

            if rejection_reasons:
                previous_reasoning += (
                    "\nValidator đã từ chối quyết định keep vì: "
                    + "; ".join(rejection_reasons)
                    + ". Không được giữ rủi ro nếu chưa khắc phục; "
                    "hãy tìm bằng chứng mới nếu còn lượt, nếu không thì drop."
                )
                continue

            return VerifiedRisk(
                candidate_id=candidate.candidate_id,
                risk_type=candidate.risk_type,
                description=candidate.description,
                contract_chunk_ids=candidate.related_chunk_ids,
                severity=candidate.severity,
                legal_references=usable_references,
                evidence_type="direct_contradictory",
                confidence=decision.confidence,
                analysis=decision.analysis,
                conclusion=decision.conclusion,
            )

    return None


# ============================================================
# LEGAL URL VALIDATION
# ============================================================

def _is_allowed_legal_url(url: str) -> bool:
    """Chỉ chấp nhận URL thuộc domain pháp luật được phép."""

    from urllib.parse import urlparse

    parsed = urlparse(url)

    if parsed.scheme not in {"http", "https"}:
        return False

    hostname = (
        parsed.hostname or ""
    ).lower().rstrip(".")

    return any(
        hostname == domain
        or hostname.endswith("." + domain)
        for domain in ALLOWED_LEGAL_DOMAINS
    )


# ============================================================
# AGENT 3: VERIFY ALL CANDIDATES
# ============================================================

def run_agent_3(
    candidates: list[MergedRiskCandidate],
    contract_chunks: list[ContractChunk],
    trace: list[dict[str, Any]] | None = None,
) -> list[VerifiedRisk]:
    """Xác minh lần lượt các ứng viên đã được gộp."""

    verified: list[VerifiedRisk] = []

    for candidate in candidates:
        try:
            result = run_agent_3_issue(
                candidate=candidate,
                contract_chunks=contract_chunks,
                trace=trace,
            )

        except Exception:
            continue

        if result is not None:
            verified.append(result)

    return verified
