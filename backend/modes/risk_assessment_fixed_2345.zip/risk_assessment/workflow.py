
from langgraph.graph import StateGraph, START, END

from .schemas import RiskAssessmentState
from .nodes import (
    create_global_summary,
    create_batches_node,
    run_agent_1_node,
    run_agent_2_node,
    merge_candidates_node,
    run_agent_3_node,
    build_final_assessment_node,
)


def route_after_merge(state: RiskAssessmentState) -> str:
    """
    Chỉ gọi Agent 3 nếu Agent 1 hoặc Agent 2 phát hiện
    ít nhất một rủi ro ứng viên sau khi gộp kết quả.
    """
    candidates = state.get("candidate_issues", [])

    if candidates:
        return "run_agent_3"

    return "build_final_assessment"


def build_risk_assessment_graph():
    """
    Xây dựng workflow đánh giá rủi ro hợp đồng.

    Luồng xử lý:
    START
      -> create_global_summary
      -> create_batches
      -> Agent 1 và Agent 2 chạy song song
      -> merge_candidates
      -> [Có ứng viên?]
           Có  -> Agent 3 -> build_final_assessment
           Không ----------------> build_final_assessment
      -> END
    """

    workflow = StateGraph(RiskAssessmentState)

    # 1. Khai báo các node
    workflow.add_node(
        "create_global_summary",
        create_global_summary,
    )

    workflow.add_node(
        "create_batches",
        create_batches_node,
    )

    workflow.add_node(
        "run_agent_1",
        run_agent_1_node,
    )

    workflow.add_node(
        "run_agent_2",
        run_agent_2_node,
    )

    workflow.add_node(
        "merge_candidates",
        merge_candidates_node,
    )

    workflow.add_node(
        "run_agent_3",
        run_agent_3_node,
    )

    workflow.add_node(
        "build_final_assessment",
        build_final_assessment_node,
    )

    # 2. Luồng bắt đầu
    workflow.add_edge(
        START,
        "create_global_summary",
    )

    workflow.add_edge(
        "create_global_summary",
        "create_batches",
    )

    # 3. Agent 1 và Agent 2 chạy song song
    workflow.add_edge(
        "create_batches",
        "run_agent_1",
    )

    workflow.add_edge(
        "create_batches",
        "run_agent_2",
    )

    # 4. Chờ cả hai Agent hoàn thành rồi mới gộp kết quả
    workflow.add_edge(
    ["run_agent_1", "run_agent_2"],
    "merge_candidates",
)

    # 5. Quyết định có cần gọi Agent 3 hay không
    workflow.add_conditional_edges(
        "merge_candidates",
        route_after_merge,
        {
            "run_agent_3": "run_agent_3",
            "build_final_assessment": "build_final_assessment",
        },
    )

    # 6. Hoàn thiện báo cáo
    workflow.add_edge(
        "run_agent_3",
        "build_final_assessment",
    )

    workflow.add_edge(
        "build_final_assessment",
        END,
    )

    return workflow.compile()
