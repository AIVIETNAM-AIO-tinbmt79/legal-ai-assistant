
from __future__ import annotations

import logging

from .agent import (
    merge_agent_results,
    run_agent_1,
    run_agent_2,
    run_agent_3,
)
from .chunker import create_batches
from .schemas import (
    AgentTrace,
    ContractChunk,
    FinalRiskAssessment,
    RiskAssessmentState,
)

logger = logging.getLogger(__name__)


# ============================================================
# NODE 1: TÓM TẮT CẤU TRÚC HỢP ĐỒNG
# ============================================================

def create_global_summary(
    state: RiskAssessmentState,
) -> dict:
    """Tạo thống kê cơ bản về hợp đồng."""

    chunks: list[ContractChunk] = state.get("chunks", [])

    articles = {
        chunk.article
        for chunk in chunks
        if chunk.article
    }

    summary = (
        f"Hợp đồng có {len(chunks)} đoạn nội dung "
        f"và {len(articles)} điều được nhận diện."
    )

    return {
        "contract_summary": summary,
    }


# ============================================================
# NODE 2: CHIA BATCH
# ============================================================

def create_batches_node(
    state: RiskAssessmentState,
) -> dict:
    """Chia các chunk thành những batch phục vụ phân tích."""

    chunks = state.get("chunks", [])

    if not chunks:
        raise ValueError(
            "Không có nội dung hợp đồng để phân tích."
        )

    batches = create_batches(chunks)

    if not batches:
        raise ValueError(
            "Không tạo được batch từ nội dung hợp đồng."
        )

    return {
        "batches": batches,
    }


# ============================================================
# NODE 3: AGENT 1
# ============================================================

def run_agent_1_node(
    state: RiskAssessmentState,
) -> dict:
    """Agent 1 độc lập phát hiện ứng viên rủi ro."""

    results = run_agent_1(
        batches=state.get("batches", [])
    )

    logger.info(
        "Agent 1 hoàn thành: %d batch kết quả.",
        len(results),
    )

    return {
        "agent_1_results": results,
    }


# ============================================================
# NODE 4: AGENT 2
# ============================================================

def run_agent_2_node(
    state: RiskAssessmentState,
) -> dict:
    """Agent 2 độc lập phát hiện ứng viên rủi ro."""

    results = run_agent_2(
        batches=state.get("batches", [])
    )

    logger.info(
        "Agent 2 hoàn thành: %d batch kết quả.",
        len(results),
    )

    return {
        "agent_2_results": results,
    }


# ============================================================
# NODE 5: GỘP ỨNG VIÊN
# ============================================================

def merge_candidates_node(
    state: RiskAssessmentState,
) -> dict:
    """
    Gộp kết quả của hai agent.

    Chưa xác nhận ứng viên là vi phạm pháp luật ở bước này.
    """

    candidates = merge_agent_results(
        agent_1_results=state.get("agent_1_results", []),
        agent_2_results=state.get("agent_2_results", []),
    )

    logger.info(
        "Đã gộp được %d ứng viên rủi ro.",
        len(candidates),
    )

    return {
        "candidate_issues": candidates,
    }


# ============================================================
# NODE 6: AGENT 3 XÁC MINH PHÁP LÝ
# ============================================================

def run_agent_3_node(
    state: RiskAssessmentState,
) -> dict:
    """
    Chỉ chạy khi workflow xác định có ứng viên.

    Agent 3 đối chiếu các ứng viên với căn cứ pháp luật.
    """

    candidates = state.get("candidate_issues", [])

    # Phòng vệ bổ sung: workflow bình thường đã bỏ qua node này
    # nếu không có ứng viên.
    if not candidates:
        logger.info(
            "Không có ứng viên. Bỏ qua xác minh pháp lý."
        )

        return {
            "verified_issues": [],
            "agent_trace": [],
            "agent3_tool_calls": 0,
        }

    trace: list[dict] = []

    verified = run_agent_3(
        candidates=candidates,
        contract_chunks=state.get("chunks", []),
        trace=trace,
    )

    logger.info(
        "Agent 3 xác minh: %d/%d ứng viên được giữ lại.",
        len(verified),
        len(candidates),
    )

    # Chỉ giữ trace hợp lệ theo schema.
    valid_trace: list[AgentTrace] = []

    for item in trace:
        try:
            valid_trace.append(
                AgentTrace.model_validate(item)
            )
        except Exception:
            logger.warning(
                "Bỏ qua một bản ghi AgentTrace không hợp lệ."
            )

    tool_calls = sum(
        1
        for item in valid_trace
        if item.action == "search_legal"
    )

    return {
        "verified_issues": verified,
        "agent_trace": valid_trace,
        "agent3_tool_calls": tool_calls,
    }


# ============================================================
# NODE 7: TẠO BÁO CÁO CUỐI
# ============================================================

def build_final_assessment_node(
    state: RiskAssessmentState,
) -> dict:
    """
    Tạo báo cáo cuối từ các rủi ro đã được xác minh.

    Không đưa các ứng viên chưa đủ căn cứ vào danh sách vi phạm.
    """

    verified_issues = state.get("verified_issues", [])
    candidates = state.get("candidate_issues", [])

    if not verified_issues:
        if not candidates:
            summary = (
                "Hệ thống chưa phát hiện ứng viên rủi ro cụ thể "
                "qua bước rà soát nội dung hợp đồng. Kết quả này "
                "không đồng nghĩa với việc hợp đồng hoàn toàn "
                "không có rủi ro pháp lý."
            )
        else:
            summary = (
                "Hệ thống đã phát hiện một số vấn đề cần xem xét, "
                "nhưng chưa thu thập hoặc xác minh được đủ căn cứ "
                "để kết luận có mâu thuẫn trực tiếp với pháp luật. "
                "Các ứng viên chưa đủ bằng chứng không được đưa "
                "vào danh sách rủi ro pháp lý đã xác minh."
            )

        result = FinalRiskAssessment(
            risk_level="low",
            summary=summary,
            issues=[],
            recommendations=[
                (
                    "Nếu hợp đồng có giá trị lớn hoặc ảnh hưởng "
                    "đến quyền và nghĩa vụ quan trọng, nên nhờ "
                    "chuyên gia pháp lý rà soát trước khi ký."
                )
            ],
        )

        return {
            "final_assessment": result,
        }

    severity_rank = {
        "low": 1,
        "medium": 2,
        "high": 3,
    }

    highest_severity = max(
        severity_rank.get(issue.severity, 1)
        for issue in verified_issues
    )

    risk_level = {
        1: "low",
        2: "medium",
        3: "high",
    }[highest_severity]

    recommendations = []

    for issue in verified_issues:
        recommendations.append(
            (
                f"Rà soát và cân nhắc điều chỉnh nội dung liên quan "
                f"đến '{issue.risk_type}'. Đối chiếu điều khoản "
                f"với căn cứ pháp luật được dẫn trong kết quả xác minh "
                f"trước khi quyết định phương án xử lý."
            )
        )

    result = FinalRiskAssessment(
        risk_level=risk_level,
        summary=(
            f"Hệ thống xác minh được {len(verified_issues)} "
            f"vấn đề có căn cứ cho thấy điều khoản hợp đồng "
            f"mâu thuẫn trực tiếp với quy định pháp luật. "
            f"Báo cáo chỉ liệt kê các vấn đề đã vượt qua bước "
            f"xác minh bằng chứng."
        ),
        issues=verified_issues,
        recommendations=recommendations,
    )

    return {
        "final_assessment": result,
    }
