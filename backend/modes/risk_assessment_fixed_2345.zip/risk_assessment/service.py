
from .chunker import convert_chunks
from .schemas import FinalRiskAssessment
from .workflow import build_risk_assessment_graph

from chunking.chunk_models import Chunk
from indexing.bm25_indexer import BM25Indexer


class RiskService:
    """
    Tầng dịch vụ đánh giá rủi ro hợp đồng.

    Nhiệm vụ:
    1. Lấy chunks của hợp đồng từ BM25 index.
    2. Chuyển chunks sang schema mà các Agent sử dụng.
    3. Chạy workflow đánh giá rủi ro.
    4. Trả về báo cáo cuối cùng.
    """

    def __init__(self, bm25_indexer=None):
        self.bm25_indexer = bm25_indexer or BM25Indexer()
        self.graph = build_risk_assessment_graph()
        self._index_mtime_ns = None

    def _load_index_if_needed(self):
        """Nạp lại BM25 index khi file index thay đổi."""
        index_path = self.bm25_indexer.index_path

        if not index_path.exists():
            raise FileNotFoundError(
                f"Không tìm thấy BM25 index: {index_path}"
            )

        current_mtime = index_path.stat().st_mtime_ns

        if (
            not self.bm25_indexer.is_ready
            or self._index_mtime_ns != current_mtime
        ):
            self.bm25_indexer.load()

            # Cập nhật mốc thời gian sau khi nạp index.
            self._index_mtime_ns = index_path.stat().st_mtime_ns

    def get_contract_chunks(self, contract_id: str) -> list[Chunk]:
        """
        Lấy tất cả chunks thuộc hợp đồng được chỉ định.
        """
        if not contract_id:
            raise ValueError("contract_id không được để trống.")

        self._load_index_if_needed()

        chunks = [
            chunk
            for chunk in self.bm25_indexer.chunks
            if chunk.metadata.contract_id == contract_id
        ]

        if not chunks:
            raise ValueError(
                f"Không tìm thấy chunks cho hợp đồng: {contract_id}"
            )

        return chunks

    def assess(self, contract_id: str) -> FinalRiskAssessment:
        """
        Đánh giá rủi ro của một hợp đồng và trả về báo cáo.
        """
        # Bước 1: Lấy dữ liệu hợp đồng.
        chunks = self.get_contract_chunks(contract_id)

        # Bước 2: Chuyển sang schema ContractChunk.
        contract_chunks = convert_chunks(chunks)

        # Bước 3: Khởi tạo state đầu vào cho workflow.
        initial_state = {
            "chunks": contract_chunks,
        }

        # Bước 4: Chạy toàn bộ workflow.
        final_state = self.graph.invoke(initial_state)

        # Bước 5: Lấy kết quả cuối cùng.
        result = final_state.get("final_assessment")

        if result is None:
            raise RuntimeError(
                "Workflow kết thúc nhưng không tạo được báo cáo."
            )

        # Chấp nhận cả model Pydantic và dữ liệu dict.
        if isinstance(result, FinalRiskAssessment):
            return result

        if isinstance(result, dict):
            return FinalRiskAssessment.model_validate(result)

        raise TypeError(
            "Kiểu dữ liệu final_assessment không hợp lệ: "
            f"{type(result).__name__}"
        )
