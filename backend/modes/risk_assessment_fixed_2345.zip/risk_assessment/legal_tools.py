
from __future__ import annotations

import logging
import os
from urllib.parse import urlparse

from tavily import TavilyClient

from config.settings import Settings
from .schemas import (
    LegalReference,
    LegalSearchRequest,
    LegalSearchResult,
)

logger = logging.getLogger(__name__)

DEFAULT_ALLOWED_DOMAINS = [
    "chinhphu.vn",
    "thuvienphapluat.vn",
]

MAX_RESULTS = 3
MIN_CONTENT_LENGTH = 100


def _get_api_key() -> str:
    """Lấy API key từ settings hoặc biến môi trường."""
    api_key = getattr(Settings, "TAVILY_API_KEY", None)

    if not api_key:
        api_key = os.getenv("TAVILY_API_KEY")

    if not api_key:
        raise RuntimeError("Chưa cấu hình TAVILY_API_KEY")

    return api_key


def _normalize_domain(domain: str) -> str:
    return domain.lower().strip().rstrip(".")


def _is_allowed_url(
    url: str,
    allowed_domains: list[str],
) -> bool:
    """Chỉ chấp nhận domain được phép và các subdomain."""
    try:
        parsed = urlparse(url)

        if parsed.scheme not in ("http", "https"):
            return False

        hostname = parsed.hostname

        if not hostname:
            return False

        hostname = _normalize_domain(hostname)

        return any(
            hostname == _normalize_domain(domain)
            or hostname.endswith(
                "." + _normalize_domain(domain)
            )
            for domain in allowed_domains
        )

    except (ValueError, AttributeError):
        return False


def _get_allowed_domains(
    request: LegalSearchRequest,
) -> list[str]:
    """Chỉ cho phép tìm kiếm trong domain hệ thống đã duyệt."""
    allowed = {
        _normalize_domain(domain)
        for domain in DEFAULT_ALLOWED_DOMAINS
    }

    selected = []

    for domain in request.allowed_domains:
        domain = _normalize_domain(domain)

        if domain in allowed and domain not in selected:
            selected.append(domain)

    return selected


def _create_reference(
    item: dict,
) -> LegalReference:
    """Chuyển kết quả Tavily thành LegalReference."""
    url = (item.get("url") or "").strip()
    content = (item.get("content") or "").strip()
    title = (item.get("title") or "").strip()

    parsed = urlparse(url)
    domain = parsed.hostname or ""

    normalized_domain = _normalize_domain(domain)

    return LegalReference(
        title=title,
        url=url,
        snippet=content[:500],
        content=content,
        domain=domain,
        published_date=None,
        effective_date=None,
        is_official_source=(
            normalized_domain == "chinhphu.vn"
            or normalized_domain.endswith(".chinhphu.vn")
        ),
    )


def legal_search(
    request: LegalSearchRequest,
) -> LegalSearchResult:
    """
    Tìm kiếm căn cứ pháp luật bằng Tavily.

    Giữ nguyên giao diện legal_search(request)
    và kiểu kết quả LegalSearchResult.
    """
    query = request.query.strip()

    if not query:
        return LegalSearchResult(
            query="",
            errors=["Truy vấn tìm kiếm đang trống."],
        )

    allowed_domains = _get_allowed_domains(request)

    if not allowed_domains:
        return LegalSearchResult(
            query=query,
            errors=["Không có domain nào được phép tìm kiếm."],
        )

    references = []
    errors = []
    search_count = 0

    try:
        client = TavilyClient(api_key=_get_api_key())

        max_results = min(request.max_results,MAX_RESULTS)

        response = client.search(
            query=query,
            search_depth="basic",
            max_results=max_results,
            include_domains=allowed_domains,
            include_answer=False,
        )

        raw_results = response.get("results", [])
        search_count = len(raw_results)

        for item in raw_results:
            url = (item.get("url") or "").strip()

            if not _is_allowed_url(url, allowed_domains):
                logger.warning(
                    "[LegalSearch] Rejected URL: %s",
                    url,
                )
                continue

            content = (item.get("content") or "").strip()

            if len(content) < MIN_CONTENT_LENGTH:
                logger.info(
                    "[LegalSearch] Skipped short content: %s (%d chars)",
                    url,
                    len(content),
                )
                continue

            try:
                reference = _create_reference(item)
                references.append(reference)

            except Exception:
                logger.exception(
                    "[LegalSearch] Could not create reference: %s",
                    url,
                )

        logger.info(
            "[LegalSearch] query=%r search_count=%d references=%d",
            query,
            search_count,
            len(references),
        )

    except Exception as exc:
        logger.exception("[LegalSearch] Tavily search failed")
        errors.append(
            f"Tavily search failed: {type(exc).__name__}: {exc}"
        )

    return LegalSearchResult(
        query=query,
        references=references,
        search_count=search_count,
        errors=errors,
    )
