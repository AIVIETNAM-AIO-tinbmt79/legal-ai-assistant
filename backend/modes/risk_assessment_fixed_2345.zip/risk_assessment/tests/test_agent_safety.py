"""Regression tests for legal-evidence validation and bounded retries.

Run these from the parent application environment so config.settings and
runtime dependencies (OpenAI, Tavily, Pydantic) are available.
"""

import json

import pytest

try:
    from modes.risk_assessment import agent, prompts
    from modes.risk_assessment.schemas import (
        ContractChunk,
        LegalReference,
        LegalSearchResult,
        MergedRiskCandidate,
    )
except ModuleNotFoundError:
    from risk_assessment import agent, prompts
    from risk_assessment.schemas import (
        ContractChunk,
        LegalReference,
        LegalSearchResult,
        MergedRiskCandidate,
    )

# Keep imports identical regardless of whether the package lives under modes/.
from pydantic import ValidationError



def _chunk(chunk_id="chunk-1"):
    return ContractChunk(
        id=chunk_id,
        text="Bên mua phải thanh toán đầy đủ trong vòng 10 ngày.",
    )


def _candidate():
    return MergedRiskCandidate(
        candidate_id="candidate_0001",
        risk_type="Điều khoản thanh toán",
        description="Thời hạn thanh toán có thể mâu thuẫn quy định bắt buộc.",
        related_chunk_ids=["chunk-1"],
        severity="medium",
        reasons=["Thời hạn thanh toán cần được kiểm tra."],
        detected_by=["agent_1"],
        legal_question="Quy định pháp luật về thời hạn thanh toán là gì?",
    )


def _reference(url="https://thuvienphapluat.vn/van-ban/test"):
    return LegalReference(
        title="Văn bản pháp luật về thanh toán",
        url=url,
        domain="thuvienphapluat.vn",
        content=("Điều 1. Quy định về nghĩa vụ thanh toán. " * 12).strip(),
        is_official_source=False,
    )


def _decision(action, **kwargs):
    data = {
        "action": action,
        "reasoning": "Đánh giá theo tài liệu đã cung cấp.",
        "evidence_type": "insufficient",
        "confidence": "low",
        "analysis": "",
        "conclusion": "",
        "search_request": None,
    }
    data.update(kwargs)
    return json.dumps(data, ensure_ascii=False)


def test_detection_rejects_chunk_id_from_another_batch(monkeypatch):
    responses = iter([
        json.dumps({"risks": [{
            "chunk_id": "chunk-b",
            "risk_type": "payment",
            "description": "test",
            "severity": "medium",
            "reason": "test",
        }]}),
        json.dumps({"risks": [{
            "chunk_id": "chunk-b",
            "risk_type": "payment",
            "description": "test",
            "severity": "medium",
            "reason": "test",
        }]}),
    ])
    monkeypatch.setattr(agent, "call_llm", lambda *_: next(responses))

    results = agent._run_detection_agent(
        batches=[[_chunk("chunk-a")], [_chunk("chunk-b")]],
        agent_name="agent_1",
        system_prompt="test",
    )

    assert results[0].risks == []
    assert len(results[1].risks) == 1
    assert results[1].risks[0].chunk_id == "chunk-b"


def test_prompt_rejects_external_domain_even_if_content_is_long():
    refs = [{
        "title": "Untrusted page",
        "url": "https://example.com/law",
        "content": "Legal text " * 30,
    }]
    normalized = prompts._normalize_legal_references(refs)
    assert normalized == []


def test_repeated_query_is_not_sent_to_legal_search(monkeypatch):
    query = "Quy định pháp luật về thời hạn thanh toán"
    responses = iter([
        _decision("search_legal", search_request={"query": query}),
        _decision("search_legal", search_request={"query": query}),
        _decision("drop"),
    ])
    calls = []
    monkeypatch.setattr(agent, "call_llm", lambda *_: next(responses))

    def fake_search(request):
        calls.append(request.query)
        return LegalSearchResult(query=request.query, references=[_reference()])

    monkeypatch.setattr(agent, "legal_search", fake_search)
    trace = []
    result = agent.run_agent_3_issue(_candidate(), [_chunk()], trace=trace)

    assert result is None
    assert calls == [query]
    assert sum(item["action"] == "search_legal" for item in trace) == 1
    assert any(item["action"] == "search_legal_skipped_duplicate" for item in trace)


def test_search_results_accumulate_across_distinct_queries(monkeypatch):
    responses = iter([
        _decision("search_legal", search_request={"query": "quy định thanh toán hợp đồng"}),
        _decision("search_legal", search_request={"query": "điều khoản thanh toán luật thương mại"}),
        _decision(
            "keep",
            evidence_type="direct_contradictory",
            confidence="high",
            analysis="Điều khoản hợp đồng mâu thuẫn trực tiếp với quy định được trích dẫn.",
            conclusion="Xác nhận rủi ro trong phạm vi nội dung đã đối chiếu.",
        ),
    ])
    search_index = iter([_reference("https://thuvienphapluat.vn/van-ban/a"), _reference("https://chinhphu.vn/van-ban/b")])
    monkeypatch.setattr(agent, "call_llm", lambda *_: next(responses))

    def fake_search(request):
        ref = next(search_index)
        return LegalSearchResult(query=request.query, references=[ref])

    monkeypatch.setattr(agent, "legal_search", fake_search)
    result = agent.run_agent_3_issue(_candidate(), [_chunk()])

    assert result is not None
    assert result.evidence_type == "direct_contradictory"
    assert len(result.legal_references) == 2


def test_keep_without_direct_evidence_is_not_accepted(monkeypatch):
    responses = iter([
        _decision("search_legal", search_request={"query": "quy định thanh toán hợp đồng"}),
        _decision(
            "keep",
            evidence_type="insufficient",
            confidence="high",
            analysis="Có nội dung liên quan nhưng chưa chứng minh mâu thuẫn.",
            conclusion="Chưa đủ căn cứ xác nhận vi phạm.",
        ),
        _decision("drop"),
    ])
    monkeypatch.setattr(agent, "call_llm", lambda *_: next(responses))
    monkeypatch.setattr(
        agent,
        "legal_search",
        lambda request: LegalSearchResult(query=request.query, references=[_reference()]),
    )

    result = agent.run_agent_3_issue(_candidate(), [_chunk()])
    assert result is None


def test_keep_without_usable_references_is_not_accepted(monkeypatch):
    short_ref = LegalReference(
        title="Short snippet",
        url="https://thuvienphapluat.vn/van-ban/short",
        domain="thuvienphapluat.vn",
        content="Đoạn trích ngắn.",
    )
    responses = iter([
        _decision("search_legal", search_request={"query": "quy định thanh toán hợp đồng"}),
        _decision(
            "keep",
            evidence_type="direct_contradictory",
            confidence="high",
            analysis="Mô tả phân tích.",
            conclusion="Mô tả kết luận.",
        ),
        _decision("drop"),
    ])
    monkeypatch.setattr(agent, "call_llm", lambda *_: next(responses))
    monkeypatch.setattr(
        agent,
        "legal_search",
        lambda request: LegalSearchResult(query=request.query, references=[short_ref]),
    )

    result = agent.run_agent_3_issue(_candidate(), [_chunk()])
    assert result is None


def test_search_error_can_retry_with_a_different_query(monkeypatch):
    responses = iter([
        _decision("search_legal", search_request={"query": "truy vấn lỗi lần một"}),
        _decision("search_legal", search_request={"query": "truy vấn khác về nghĩa vụ thanh toán"}),
        _decision(
            "keep",
            evidence_type="direct_contradictory",
            confidence="medium",
            analysis="Đối chiếu nội dung quy định với điều khoản cụ thể.",
            conclusion="Có mâu thuẫn trực tiếp trong phạm vi nguồn đã cung cấp.",
        ),
    ])
    monkeypatch.setattr(agent, "call_llm", lambda *_: next(responses))
    calls = []

    def fake_search(request):
        calls.append(request.query)
        if len(calls) == 1:
            raise RuntimeError("temporary Tavily failure")
        return LegalSearchResult(query=request.query, references=[_reference()])

    monkeypatch.setattr(agent, "legal_search", fake_search)
    result = agent.run_agent_3_issue(_candidate(), [_chunk()])

    assert calls == ["truy vấn lỗi lần một", "truy vấn khác về nghĩa vụ thanh toán"]
    assert result is not None
    assert len(result.legal_references) == 1


def test_verified_risk_schema_requires_direct_evidence_and_reference():
    with pytest.raises(Exception):
        agent.VerifiedRisk(
            candidate_id="candidate_0001",
            risk_type="test",
            description="test",
            contract_chunk_ids=["chunk-1"],
            severity="medium",
            legal_references=[],
            evidence_type="insufficient",
            confidence="high",
            analysis="analysis",
            conclusion="conclusion",
        )
