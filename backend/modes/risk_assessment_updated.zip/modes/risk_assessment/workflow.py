from langgraph.graph import StateGraph, START, END

from .nodes import (
    build_final_assessment_node,
    create_batches_node,
    create_global_summary,
    merge_candidates_node,
    run_agent_1_node,
    run_agent_2_node,
    run_agent_3_node,
)
from .schemas import RiskAssessmentState


def build_risk_assessment_graph():
    graph = StateGraph(
        RiskAssessmentState
    )

    graph.add_node(
        "create_global_summary",
        create_global_summary,
    )

    graph.add_node(
        "create_batches",
        create_batches_node,
    )

    graph.add_node(
        "agent_1",
        run_agent_1_node,
    )

    graph.add_node(
        "agent_2",
        run_agent_2_node,
    )

    graph.add_node(
        "merge_candidates",
        merge_candidates_node,
    )

    graph.add_node(
        "agent_3",
        run_agent_3_node,
    )

    graph.add_node(
        "final_report",
        build_final_assessment_node,
    )

    graph.add_edge(
        START,
        "create_global_summary",
    )

    graph.add_edge(
        "create_global_summary",
        "create_batches",
    )

    # Hai agent chạy độc lập.
    graph.add_edge(
        "create_batches",
        "agent_1",
    )

    graph.add_edge(
        "create_batches",
        "agent_2",
    )

    # Chỉ merge sau khi cả hai agent hoàn thành.
    graph.add_edge(
        ["agent_1", "agent_2"],
        "merge_candidates",
    )

    graph.add_edge(
        "merge_candidates",
        "agent_3",
    )

    graph.add_edge(
        "agent_3",
        "final_report",
    )

    graph.add_edge(
        "final_report",
        END,
    )

    return graph.compile()
