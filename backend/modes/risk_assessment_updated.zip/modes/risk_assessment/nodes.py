from .agent import (
    merge_agent_results,
    run_agent_1,
    run_agent_2,
    run_agent_3,
)
from .chunker import create_batches
from .schemas import (
    AgentTrace,
    FinalRiskAssessment,
    RiskAssessmentState,
)


def create_global_summary(
    state: RiskAssessmentState,
):
    chunks = state.get("chunks", [])

    articles = {
        chunk.article
        for chunk in chunks
        if chunk.article
    }

    summary = (
        f"Hợp đồng gồm {len(chunks)} chunk, "
        f"thuộc {len(articles)} điều khác nhau."
    )

    return {
        "contract_summary": summary,
    }


def create_batches_node(
    state: RiskAssessmentState,
):
    batches = create_batches(
        state.get("chunks", [])
    )

    return {
        "batches": batches,
    }


def run_agent_1_node(
    state: RiskAssessmentState,
):
    results = run_agent_1(
        state.get("batches", [])
    )

    return {
        "agent_1_results": results,
    }


def run_agent_2_node(
    state: RiskAssessmentState,
):
    results = run_agent_2(
        state.get("batches", [])
    )

    return {
        "agent_2_results": results,
    }


def merge_candidates_node(
    state: RiskAssessmentState,
):
    issues = merge_agent_results(
        state.get("agent_1_results", []),
        state.get("agent_2_results", []),
    )

    return {
        "candidate_issues": issues,
    }


def run_agent_3_node(
    state: RiskAssessmentState,
):
    trace = []

    verified = run_agent_3(
        issues=state.get("candidate_issues", []),
        contract_chunks=state.get("chunks", []),
        trace=trace,
    )

    return {
        "verified_issues": verified,
        "agent_trace": [
            AgentTrace.model_validate(item)
            for item in trace
        ],
    }


def build_final_assessment_node(
    state: RiskAssessmentState,
):
    issues = state.get("verified_issues", [])

    if not issues:
        result = FinalRiskAssessment(
            risk_level="low",
            summary=(
                "Không có vấn đề pháp lý nào được xác minh "
                "là mâu thuẫn trực tiếp với căn cứ pháp luật "
                "được truy xuất."
            ),
            issues=[],
            recommendations=[],
        )

        return {
            "final_assessment": result,
        }

    highest = max(
        (
            {"low": 1, "medium": 2, "high": 3}[issue.severity]
            for issue in issues
        ),
        default=1,
    )

    risk_level = {
        1: "low",
        2: "medium",
        3: "high",
    }[highest]

    recommendations = [
        (
            f"Xem xét lại điều khoản liên quan đến "
            f"{issue.risk_type} dựa trên căn cứ pháp luật "
            f"đã được đối chiếu."
        )
        for issue in issues
    ]

    result = FinalRiskAssessment(
        risk_level=risk_level,
        summary=(
            f"Phát hiện {len(issues)} vấn đề có dấu hiệu "
            f"rủi ro pháp lý sau bước kiểm chứng pháp luật."
        ),
        issues=issues,
        recommendations=recommendations,
    )

    return {
        "final_assessment": result,
    }
