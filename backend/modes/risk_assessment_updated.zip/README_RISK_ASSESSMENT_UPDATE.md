# Risk assessment mode update

## Files changed
- `modes/risk_assessment/legal_tools.py`
- `modes/risk_assessment/agent.py`
- `modes/risk_assessment/prompts.py`

## Schema contract used
This update follows `/mnt/data/build_graph_v2.py`:

### Entity nodes
- Label: `Entity`
- Properties: `entity_id`, `type`, `text`, `normalized_text`, `description`,
  `occurrence_count`, `occurrences_json`, `chunk_ids`, `document_ids`

### Relationships
- Relationship type: the validated value from JSONL `relation`
- Properties: `relationship_id`, `relation`, `evidence`, `provenance_count`,
  `provenance_json`, `chunk_ids`, `document_ids`, `evidence_list`, `titles`,
  `needs_semantic_review`, `deduplication_status`

Full legal chunk content remains in `chunks.jsonl`; graph nodes and edges carry
chunk/document provenance arrays.

## Behavior changes
1. `legal_tools.py` reads actual Entity types and relationship types from Neo4j.
2. `get_graph_schema_context()` supplies Agent 3 with the complete type inventory
   plus a bounded set of entities and relationships related to the current risk.
3. Entity/relationship retrieval reads `chunk_ids` arrays instead of assuming
   per-occurrence `chunk_id` and `document_id` properties.
4. Relationship/entity type requests from Agent 3 are filtered against the real
   schema before use.
5. Agent 3 does not write raw Cypher. It emits a structured search request;
   Python builds and executes parameterized Cypher using the existing retrieval
   functions.
6. Existing lexical fallback, ranking, reranking, chunk loading, and result
   structures are preserved.

## Validation performed
- Python syntax compilation passed for every `.py` file in `modes/risk_assessment`.
- No live Neo4j query was executed from this environment. Run the risk mode against
  your configured AuraDB to validate connectivity and the actual graph contents.
