
from __future__ import annotations

import json
import logging
import os
import re
from typing import Any

from openai import OpenAI
from pydantic import ValidationError

from .legal_tools import legal_search
from .prompts import (
    AGENT_1_SYSTEM_PROMPT,
    AGENT_2_SYSTEM_PROMPT,
    AGENT_3_SYSTEM_PROMPT,
    AGENT_3_SPLIT_SYSTEM_PROMPT,
    build_agent3_prompt,
    build_batch_prompt,
)
from .schemas import (
    Agent3Decision,
    AgentAnalysisResult,
    ContractChunk,
    LegalReference,
    LegalSearchRequest,
    LegalSearchResult,
    MergedRiskCandidate,
    RiskCandidate,
    VerifiedRisk,
)
from config.settings import Settings

setting = Settings()

logger = logging.getLogger(__name__)


# ============================================================
# LLM CONFIGURATION
# ============================================================

FPT_BASE_URL = setting.LLM_BASE_URL


FPT_API_KEY = setting.API_LLM

FPT_MODEL = setting.LLM_MODEL

MAX_AGENT3_TOOL_CALLS_PER_ISSUE = max(
    1,
    int(os.getenv("MAX_AGENT3_TOOL_CALLS_PER_ISSUE", "2")),
)

MAX_SUBISSUES_PER_CANDIDATE = max(
    3,
    int(os.getenv("MAX_SUBISSUES_PER_CANDIDATE", "5")),
)

ALLOWED_LEGAL_DOMAINS = [
    "chinhphu.vn",
    "thuvienphapluat.vn",
]

_client: OpenAI | None = None


def get_llm_client() -> OpenAI:
    """Khởi tạo OpenAI-compatible client dùng API của FPT."""

    global _client

    if _client is None:
        if not FPT_API_KEY:
            raise RuntimeError(
                "Chưa cấu hình LLM_API_KEY trong biến môi trường."
            )

        _client = OpenAI(
            api_key=FPT_API_KEY,
            base_url=FPT_BASE_URL,
        )

    return _client


def call_llm(
    system_prompt: str,
    user_prompt: str,
    response_format: dict[str, Any] | None = None,
) -> str:
    """Gọi LLM; có thể yêu cầu endpoint trả JSON mode nếu được hỗ trợ."""

    request_args: dict[str, Any] = {
        "model": FPT_MODEL,
        "temperature": 0,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
    }

    if response_format is not None:
        request_args["response_format"] = response_format

    try:
        response = get_llm_client().chat.completions.create(**request_args)
    except Exception as exc:
        # Chỉ fallback khi endpoint không hỗ trợ response_format.
        error_text = str(exc).lower()
        format_not_supported = (
            response_format is not None
            and "response_format" in error_text
            and any(word in error_text for word in ("unsupported", "not support", "unknown", "invalid"))
        )
        if not format_not_supported:
            raise

        logger.warning(
            "Endpoint không hỗ trợ response_format; thử lại không dùng JSON mode."
        )
        request_args.pop("response_format", None)
        response = get_llm_client().chat.completions.create(**request_args)

    content = response.choices[0].message.content
    if not content or not content.strip():
        raise ValueError("LLM trả về nội dung rỗng.")

    return content.strip()


# ============================================================
# JSON PARSING
# ============================================================

def parse_json(text: str) -> dict[str, Any]:
    """
    Đọc JSON do LLM trả về.

    Hỗ trợ cả trường hợp LLM bọc JSON trong Markdown code fence.
    """

    text = (text or "").strip()

    text = re.sub(
        r"^\s*```(?:json)?\s*",
        "",
        text,
        flags=re.IGNORECASE,
    )

    text = re.sub(r"\s*```\s*$", "", text)

    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        # Thử tìm JSON object trong phần giải thích thừa của LLM.
        start = text.find("{")
        end = text.rfind("}")

        if start < 0 or end < start:
            raise ValueError("LLM không trả về JSON object hợp lệ.")

        data = json.loads(text[start:end + 1])

    if not isinstance(data, dict):
        raise ValueError("JSON do LLM trả về phải là một object.")

    return data


# ============================================================
# CONTRACT CHUNK FORMATTING
# ============================================================

def _format_batch(
    batch: list[ContractChunk],
) -> str:
    """Định dạng các chunk để đưa vào prompt."""

    parts = []

    for chunk in batch:
        parts.append(
            f"""
CHUNK_ID: {chunk.id}
HIERARCHY: {chunk.hierarchy_path or ""}
ARTICLE: {chunk.article or ""}
CLAUSE: {chunk.clause or ""}
POINT: {chunk.point or ""}
CHUNK_TYPE: {chunk.chunk_type}

CONTENT:
{chunk.text}
""".strip()
        )

    return "\n\n---\n\n".join(parts)


def _chunk_lookup(
    chunks: list[ContractChunk],
) -> dict[str, ContractChunk]:
    """Tạo bảng tra cứu chunk theo ID."""

    return {chunk.id: chunk for chunk in chunks}


# ============================================================
# AGENT 1 AND AGENT 2
# ============================================================

def _run_detection_agent(
    batches: list[list[ContractChunk]],
    agent_name: str,
    system_prompt: str,
) -> list[AgentAnalysisResult]:
    """
    Chạy một agent phát hiện rủi ro độc lập.

    Agent chỉ phát hiện ứng viên, không kết luận vi phạm pháp luật.
    """

    results: list[AgentAnalysisResult] = []
    known_chunk_ids = {
        chunk.id
        for batch in batches
        for chunk in batch
    }

    for index, batch in enumerate(batches, start=1):
        if not batch:
            continue

        prompt = build_batch_prompt(
            agent_name,
            _format_batch(batch),
        )

        raw = call_llm(system_prompt, prompt)
        data = parse_json(raw)

        raw_risks = data.get("risks", [])

        if not isinstance(raw_risks, list):
            raise ValueError(
                f"{agent_name}, batch_{index}: "
                "trường 'risks' phải là một danh sách."
            )

        risks: list[RiskCandidate] = []

        for item in raw_risks:
            if not isinstance(item, dict):
                logger.warning(
                    "%s batch_%s trả về một risk không hợp lệ.",
                    agent_name,
                    index,
                )
                continue

            try:
                risk = RiskCandidate.model_validate(item)
            except ValidationError:
                logger.warning(
                    "%s batch_%s trả về risk sai schema: %s",
                    agent_name,
                    index,
                    item,
                )
                continue

            # Không cho phép agent tham chiếu chunk không tồn tại.
            if risk.chunk_id not in known_chunk_ids:
                logger.warning(
                    "%s tham chiếu chunk không tồn tại: %s",
                    agent_name,
                    risk.chunk_id,
                )
                continue

            risks.append(risk)

        results.append(
            AgentAnalysisResult(
                agent=agent_name,
                batch_id=f"batch_{index}",
                risks=risks,
            )
        )

    return results


def run_agent_1(
    batches: list[list[ContractChunk]],
) -> list[AgentAnalysisResult]:
    """Agent 1 phát hiện các ứng viên rủi ro trong hợp đồng."""

    return _run_detection_agent(
        batches=batches,
        agent_name="agent_1",
        system_prompt=AGENT_1_SYSTEM_PROMPT,
    )


def run_agent_2(
    batches: list[list[ContractChunk]],
) -> list[AgentAnalysisResult]:
    """Agent 2 kiểm tra hợp đồng độc lập với Agent 1."""

    return _run_detection_agent(
        batches=batches,
        agent_name="agent_2",
        system_prompt=AGENT_2_SYSTEM_PROMPT,
    )


# ============================================================
# MERGE CANDIDATES
# ============================================================

def _normalize_text(value: str) -> str:
    """Chuẩn hóa văn bản để so sánh các ứng viên."""

    return re.sub(r"\s+", " ", value or "").strip().lower()


def merge_agent_results(
    agent_1_results: list[AgentAnalysisResult],
    agent_2_results: list[AgentAnalysisResult],
) -> list[MergedRiskCandidate]:
    """
    Hợp nhất kết quả độc lập của Agent 1/2 ở cấp vấn đề pháp lý con.
    Mỗi subissue được giữ riêng nếu có thể xác minh độc lập.
    """

    # Mỗi entry: (agent_name, chunk_id, issue fields, parent risk)
    flattened: list[tuple[str, str, dict[str, Any], RiskCandidate]] = []

    for result in [*agent_1_results, *agent_2_results]:
        for risk in result.risks:
            subissues = getattr(risk, "subissues", []) or []
            if subissues:
                for subissue in subissues:
                    if hasattr(subissue, "model_dump"):
                        subissue = subissue.model_dump()
                    if not isinstance(subissue, dict):
                        continue
                    risk_type = str(subissue.get("risk_type") or "").strip()
                    description = str(subissue.get("description") or "").strip()
                    legal_question = str(subissue.get("legal_question") or "").strip()
                    if not risk_type or not description or not legal_question:
                        continue
                    queries = subissue.get("search_queries", [])
                    if not isinstance(queries, list):
                        queries = []
                    queries = list(dict.fromkeys(
                        q.strip() for q in queries
                        if isinstance(q, str) and q.strip()
                    ))
                    flattened.append((
                        result.agent,
                        risk.chunk_id,
                        {
                            "risk_type": risk_type,
                            "description": description,
                            "legal_question": legal_question,
                            "search_queries": queries,
                        },
                        risk,
                    ))
            else:
                # Tương thích ngược với output agent cũ chưa có subissues.
                flattened.append((
                    result.agent,
                    risk.chunk_id,
                    {
                        "risk_type": risk.risk_type,
                        "description": risk.description,
                        "legal_question": (
                            f"Căn cứ pháp luật nào quy định cụ thể về {risk.risk_type} "
                            f"trong bối cảnh: {risk.description}? Cần xác định điều kiện "
                            "áp dụng và đối chiếu trực tiếp với điều khoản hợp đồng."
                        ),
                        "search_queries": [],
                    },
                    risk,
                ))

    # Gộp theo chunk + tên vấn đề đã chuẩn hóa. Không gộp chỉ vì cùng chunk.
    groups: dict[tuple[str, str], list[tuple[str, str, dict[str, Any], RiskCandidate]]] = {}
    for entry in flattened:
        agent_name, chunk_id, issue_data, _ = entry
        key = (chunk_id, _normalize_text(issue_data["risk_type"]))
        groups.setdefault(key, []).append(entry)

    severity_rank = {"low": 1, "medium": 2, "high": 3}
    candidates: list[MergedRiskCandidate] = []

    for index, entries in enumerate(groups.values(), start=1):
        _, chunk_id, primary_issue, primary_risk = max(
            entries,
            key=lambda entry: severity_rank.get(entry[3].severity, 1),
        )

        reasons = list(dict.fromkeys(
            risk.reason.strip()
            for _, _, _, risk in entries
            if risk.reason and risk.reason.strip()
        ))
        descriptions = list(dict.fromkeys(
            issue["description"].strip()
            for _, _, issue, _ in entries
            if issue.get("description", "").strip()
        ))
        detected_by = sorted({agent_name for agent_name, _, _, _ in entries})

        # Hợp nhất truy vấn từ hai agent, giữ thứ tự và loại truy vấn trùng.
        search_queries = list(dict.fromkeys(
            query
            for _, _, issue, _ in entries
            for query in issue.get("search_queries", [])
        ))

        candidates.append(
            MergedRiskCandidate(
                candidate_id=f"candidate_{index:04d}",
                risk_type=primary_issue["risk_type"],
                description=descriptions[0] if descriptions else primary_risk.description,
                related_chunk_ids=[chunk_id],
                severity=max(
                    (risk.severity for _, _, _, risk in entries),
                    key=lambda value: severity_rank.get(value, 1),
                ),
                reasons=reasons,
                detected_by=detected_by,
                legal_question=primary_issue["legal_question"],
                search_queries=search_queries,
            )
        )

    return candidates


# ============================================================
# AGENT 3 HELPERS
# ============================================================

def normalize_agent3_decision(
    data: dict[str, Any],
    candidate: MergedRiskCandidate,
) -> dict[str, Any]:
    """Chuẩn hóa các tên trường thường bị LLM trả sai trước khi validate."""

    data = dict(data)

    # Tương thích với output cũ: decision/explanation/evidence.
    if "action" not in data and "decision" in data:
        data["action"] = data["decision"]
    if "reasoning" not in data:
        data["reasoning"] = data.get("explanation", "")

    action_aliases = {
        "search": "search_legal",
        "search_legal": "search_legal",
        "keep": "keep",
        "drop": "drop",
        "final": "final",
    }
    action = str(data.get("action", "")).strip().lower()
    data["action"] = action_aliases.get(action, action)

    # Không để trường legacy hoặc trường lạ làm Pydantic báo extra inputs.
    data.pop("decision", None)
    data.pop("explanation", None)
    legacy_evidence = data.pop("evidence", None)
    if legacy_evidence and not data.get("analysis"):
        if isinstance(legacy_evidence, list):
            data["analysis"] = "\n".join(str(item) for item in legacy_evidence)
        else:
            data["analysis"] = str(legacy_evidence)

    data.setdefault("reasoning", "")
    data.setdefault("analysis", "")
    data.setdefault("conclusion", "")
    data.setdefault("evidence_type", "insufficient")
    data.setdefault("confidence", "low")

    for field in ("reasoning", "analysis", "conclusion"):
        if not isinstance(data.get(field), str):
            data[field] = str(data.get(field) or "")

    if data.get("confidence") not in {"low", "medium", "high"}:
        data["confidence"] = "low"

    if data["action"] == "search_legal":
        request = data.get("search_request")
        if not isinstance(request, dict):
            request = {}
        else:
            request = dict(request)

        query = request.get("query")
        if not isinstance(query, str) or not query.strip():
            queries = getattr(candidate, "search_queries", []) or []
            fallback_query = next(
                (q.strip() for q in queries if isinstance(q, str) and q.strip()),
                candidate.legal_question,
            )
            request["query"] = fallback_query

        # Chỉ thêm field nếu nó thuộc schema thực tế của LegalSearchRequest.
        request_fields = set(LegalSearchRequest.model_fields.keys())
        if "allowed_domains" in request_fields:
            request["allowed_domains"] = ALLOWED_LEGAL_DOMAINS
        if "max_results" in request_fields and not isinstance(request.get("max_results"), int):
            request["max_results"] = 5

        # Loại field lạ bên trong search_request.
        request = {key: value for key, value in request.items() if key in request_fields}
        data["search_request"] = request
    else:
        data["search_request"] = None

    # Chỉ chuyển các field được Agent3Decision cho phép sang Pydantic.
    allowed_fields = set(Agent3Decision.model_fields.keys())
    return {key: value for key, value in data.items() if key in allowed_fields}


def _format_previous_search(
    references: list[LegalReference],
) -> str:
    """Tạo nội dung ngắn gọn về kết quả tìm kiếm trước đó."""

    if not references:
        return (
            "Chưa thu thập được căn cứ pháp luật phù hợp từ "
            "lần tìm kiếm trước. Không được coi việc không tìm thấy "
            "tài liệu là bằng chứng điều khoản hợp pháp hoặc trái luật."
        )

    return "\n\n".join(
        (
            f"TIÊU ĐỀ: {ref.title}\n"
            f"URL: {ref.url}\n"
            f"NỘI DUNG: {ref.content or ref.snippet}"
        )
        for ref in references
    )


def _record_trace(
    trace: list[dict[str, Any]] | None,
    *,
    step: int,
    decision: Agent3Decision,
    candidate: MergedRiskCandidate,
    references_found: int,
) -> None:
    if trace is None:
        return

    trace.append(
        {
            "step": step,
            "action": decision.action,
            "reasoning": decision.reasoning,
            "candidate_id": candidate.candidate_id,
            "tool_query": (
                decision.search_request.query
                if decision.search_request
                else None
            ),
            "references_found": references_found,
        }
    )


# ============================================================
# SPLIT CANDIDATES INTO INDEPENDENT LEGAL SUBISSUES
# ============================================================

def split_candidate_into_legal_subissues(
    candidate: MergedRiskCandidate,
    contract_chunks: list[ContractChunk],
) -> list[tuple[MergedRiskCandidate, list[str]]]:
    """
    Agent 3 là lớp kiểm tra dự phòng:
    - Nếu Agent 1/2 đã tạo một subissue rõ ràng kèm truy vấn, dùng trực tiếp.
    - Nếu thiếu truy vấn hoặc mô tả có nhiều vấn đề độc lập, yêu cầu Agent 3
      rà soát cấu trúc và tách bổ sung.
    """

    chunk_ids = set(candidate.related_chunk_ids)
    relevant_chunks = [
        chunk for chunk in contract_chunks if chunk.id in chunk_ids
    ]
    if not relevant_chunks:
        return []

    candidate_queries = list(dict.fromkeys(
        q.strip()
        for q in (getattr(candidate, "search_queries", []) or [])
        if isinstance(q, str) and q.strip()
    ))

    combined_text = f"{candidate.risk_type} {candidate.description} {candidate.legal_question}".lower()
    multi_issue_markers = (
        ("phạt" in combined_text and ("lãi" in combined_text or "chậm trả" in combined_text)),
        ("chấm dứt" in combined_text and ("hoàn trả" in combined_text or "không hoàn" in combined_text)),
        ("bồi thường" in combined_text and "phạt" in combined_text),
        ("miễn trừ" in combined_text and "giới hạn trách nhiệm" in combined_text),
    )
    needs_split_review = not candidate_queries or any(multi_issue_markers)

    if not needs_split_review:
        return [(candidate, candidate_queries)]

    prompt = f"""
Hãy kiểm tra xem ứng viên dưới đây có chứa nhiều vấn đề pháp lý độc lập hay không.
Nếu đã là một vấn đề đơn lẻ, trả về đúng một subissue và không mở rộng sang vấn đề khác.

CANDIDATE:
{json.dumps({
    "candidate_id": candidate.candidate_id,
    "risk_type": candidate.risk_type,
    "description": candidate.description,
    "legal_question": candidate.legal_question,
    "existing_search_queries": candidate_queries,
    "reasons": candidate.reasons,
}, ensure_ascii=False, indent=2)}

NỘI DUNG HỢP ĐỒNG:
{_format_batch(relevant_chunks)}

Giới hạn tối đa {MAX_SUBISSUES_PER_CANDIDATE} subissues.
Chỉ trả JSON theo schema trong system prompt.
""".strip()

    try:
        raw = call_llm(AGENT_3_SPLIT_SYSTEM_PROMPT, prompt)
        data = parse_json(raw)
        raw_subissues = data.get("subissues", [])
    except Exception as exc:
        logger.warning(
            "Không thể kiểm tra/tách candidate %s: %s",
            candidate.candidate_id,
            type(exc).__name__,
        )
        return [(candidate, candidate_queries or [candidate.legal_question])]

    if not isinstance(raw_subissues, list) or not raw_subissues:
        return [(candidate, candidate_queries or [candidate.legal_question])]

    results: list[tuple[MergedRiskCandidate, list[str]]] = []
    seen: set[tuple[str, str]] = set()

    for item in raw_subissues[:MAX_SUBISSUES_PER_CANDIDATE]:
        if not isinstance(item, dict):
            continue

        risk_type = item.get("risk_type")
        description = item.get("description")
        legal_question = item.get("legal_question")

        if not all(
            isinstance(value, str) and value.strip()
            for value in (risk_type, description, legal_question)
        ):
            continue

        key = (_normalize_text(risk_type), _normalize_text(legal_question))
        if key in seen:
            continue
        seen.add(key)

        raw_queries = item.get("search_queries", [])
        if not isinstance(raw_queries, list):
            raw_queries = []
        queries = list(dict.fromkeys(
            query.strip()
            for query in raw_queries
            if isinstance(query, str) and query.strip()
        ))

        # Giữ truy vấn đã tạo từ Agent 1/2 nếu Agent 3 không cải thiện được.
        if not queries:
            queries = candidate_queries or [legal_question.strip()]

        subcandidate = candidate.model_copy(update={
            "candidate_id": f"{candidate.candidate_id}_sub{len(results) + 1:02d}",
            "risk_type": risk_type.strip(),
            "description": description.strip(),
            "legal_question": legal_question.strip(),
            "search_queries": queries,
        })
        results.append((subcandidate, queries))

    return results or [(candidate, candidate_queries or [candidate.legal_question])]


# ============================================================
# AGENT 3: LEGAL VERIFICATION
# ============================================================

def run_agent_3_issue(
    candidate: MergedRiskCandidate,
    contract_chunks: list[ContractChunk],
    trace: list[dict[str, Any]] | None = None,
    preferred_queries: list[str] | None = None,
) -> VerifiedRisk | None:
    """
    Xác minh một ứng viên bằng căn cứ pháp luật.

    Chỉ giữ ứng viên khi:
    - Có tài liệu pháp luật làm căn cứ.
    - Agent 3 xác định được mâu thuẫn trực tiếp.
    - Có đủ nội dung để giải thích mâu thuẫn đó.

    Nếu tìm kiếm thất bại hoặc chứng cứ không đủ, trả về None.
    """

    chunk_ids = set(candidate.related_chunk_ids)

    relevant_chunks = [
        chunk
        for chunk in contract_chunks
        if chunk.id in chunk_ids
    ]

    if not relevant_chunks:
        logger.warning(
            "Không tìm thấy chunk cho candidate %s",
            candidate.candidate_id,
        )
        return None

    references: list[LegalReference] = []
    previous_reasoning = ""
    search_attempts = 0
    search_was_attempted = False

    # Chạy truy vấn ưu tiên ngay tại đây. Không chỉ đưa query vào prompt,
    # vì LLM có thể tự tạo một truy vấn chung chung khác.
    if preferred_queries:
        first_query = preferred_queries[0].strip()
        if first_query:
            try:
                search_attempts += 1
                search_was_attempted = True
                logger.info(
                    "Agent 3 tìm kiếm subissue %s bằng truy vấn ưu tiên: %s",
                    candidate.candidate_id,
                    first_query,
                )
                initial_request = LegalSearchRequest(
                    query=first_query,
                    allowed_domains=ALLOWED_LEGAL_DOMAINS,
                    max_results=5,
                )
                initial_result: LegalSearchResult = legal_search(initial_request)
                references = [
                    ref for ref in initial_result.references
                    if _is_allowed_legal_url(ref.url)
                ]
                if trace is not None:
                    trace.append({
                        "step": 0,
                        "action": "search_legal_preferred",
                        "reasoning": "Truy vấn ưu tiên do bước phân tách subissue tạo ra.",
                        "candidate_id": candidate.candidate_id,
                        "tool_query": first_query,
                        "references_found": len(references),
                    })
            except Exception:
                logger.exception(
                    "Tìm kiếm truy vấn ưu tiên thất bại cho %s",
                    candidate.candidate_id,
                )

    for step in range(MAX_AGENT3_TOOL_CALLS_PER_ISSUE + 1):
        prompt = build_agent3_prompt(
            issue=candidate,
            contract_chunks=relevant_chunks,
            legal_references=references,
            previous_reasoning=previous_reasoning,
        )

        # Khi đã tìm kiếm nhưng không có kết quả, bổ sung chỉ dẫn rõ
        # để Agent 3 không lặp lại vô hạn cùng một truy vấn.
        if search_was_attempted and not references:
            prompt += (
                "\n\nLƯU Ý: Đã thực hiện tìm kiếm pháp luật nhưng "
                "không thu được tài liệu phù hợp. Không được bịa "
                "nguồn, điều luật hoặc URL. Hãy drop nếu không đủ "
                "chứng cứ; không lặp lại truy vấn cũ."
            )

        raw = call_llm(
            AGENT_3_SYSTEM_PROMPT,
            prompt,
            response_format={"type": "json_object"},
        )

        try:
            decision_data = parse_json(raw)
        except Exception:
            logger.exception(
                "Agent 3 không trả JSON parse được cho %s. Raw output: %r",
                candidate.candidate_id,
                raw,
            )
            return None
        decision_data = normalize_agent3_decision(
            decision_data,
            candidate,
        )

        try:
            decision = Agent3Decision.model_validate(decision_data)
        except ValidationError as exc:
            logger.warning(
                "Agent 3 trả về dữ liệu sai schema cho %s: %s | Raw output: %r",
                candidate.candidate_id,
                exc,
                raw,
            )
            return None

        previous_reasoning = decision.reasoning

        _record_trace(
            trace,
            step=step + 1,
            decision=decision,
            candidate=candidate,
            references_found=len(references),
        )

        # ----------------------------------------------------
        # Search legal sources only when Agent 3 requests it.
        # ----------------------------------------------------
        if decision.action == "search_legal":
            if search_attempts >= MAX_AGENT3_TOOL_CALLS_PER_ISSUE:
                logger.info(
                    "Đã đạt giới hạn tìm kiếm cho %s",
                    candidate.candidate_id,
                )
                return None

            search_request = decision.search_request

            if search_request is None:
                return None

            search_attempts += 1
            search_was_attempted = True

            try:
                tool_result: LegalSearchResult = legal_search(
                    search_request
                )
            except Exception:
                logger.exception(
                    "Tìm kiếm pháp luật thất bại cho %s",
                    candidate.candidate_id,
                )
                references = []
                continue

            # Chỉ giữ tài liệu thuộc đúng hai miền cho phép.
            # legal_tools vẫn phải thực hiện kiểm tra miền ở phía công cụ.
            references = [
                ref
                for ref in tool_result.references
                if _is_allowed_legal_url(ref.url)
            ]

            continue

        # ----------------------------------------------------
        # Drop / insufficient evidence: exclude the candidate.
        # ----------------------------------------------------
        if decision.action in {"drop", "final"}:
            return None

        # ----------------------------------------------------
        # Keep only direct contradictions with legal evidence.
        # ----------------------------------------------------
        if decision.action == "keep":

            relevant_references = filter_relevant_legal_references(
                candidate=candidate,
                contract_chunks=relevant_chunks,
                references=references,
            )

            if not relevant_references:
                logger.info(
                    "Không giữ %s vì không có chứng cứ pháp luật "
                    "liên quan trực tiếp.",
                    candidate.candidate_id,
                )
                return None

            # 4. Phải có bằng chứng mâu thuẫn trực tiếp.
            if decision.evidence_type != "direct_contradictory":
                return None

            # 5. Phải có phân tích và kết luận.
            if (
                not decision.analysis.strip()
                or not decision.conclusion.strip()
            ):
                return None

            # 6. Chỉ chấp nhận độ tin cậy trung bình hoặc cao.
            if decision.confidence not in {"medium", "high"}:
                return None

            # 7. Chỉ lưu các tài liệu đã qua bước lọc liên quan.
            return VerifiedRisk(
                candidate_id=candidate.candidate_id,
                risk_type=candidate.risk_type,
                description=candidate.description,
                contract_chunk_ids=candidate.related_chunk_ids,
                severity=candidate.severity,
                legal_references=relevant_references,
                evidence_type="direct_contradictory",
                confidence=decision.confidence,
                analysis=decision.analysis,
                conclusion=decision.conclusion,
            )


        return None



def filter_relevant_legal_references(
    candidate: MergedRiskCandidate,
    contract_chunks: list[ContractChunk],
    references: list[LegalReference],
) -> list[LegalReference]:
    """
    Chỉ giữ tài liệu có nội dung pháp luật trực tiếp liên quan
    đến rủi ro hợp đồng đang được xác minh.
    """
    if not references:
        return []

    contract_text = "\n\n".join(
        chunk.content
        for chunk in contract_chunks
        if chunk.content
    )

    legal_documents = []

    for i, ref in enumerate(references):
        content = (getattr(ref, "content", "") or "").strip()
        snippet = (getattr(ref, "snippet", "") or "").strip()

        legal_documents.append({
            "index": i,
            "title": getattr(ref, "title", ""),
            "url": getattr(ref, "url", ""),
            "content": (content or snippet)[:4000],
        })

    system_prompt = """
Bạn là bộ kiểm tra tính liên quan của chứng cứ pháp luật.

Nhiệm vụ: xác định tài liệu nào thực sự hỗ trợ hoặc phản bác
nhận định rủi ro cụ thể trong điều khoản hợp đồng.

Chỉ chấp nhận tài liệu khi:
1. Nội dung đề cập trực tiếp đến vấn đề pháp lý đang kiểm tra.
2. Có nội dung quy phạm hoặc căn cứ pháp luật cụ thể hỗ trợ
   nhận định, không chỉ có chủ đề tương tự.
3. Có thể giải thích mối liên hệ giữa quy định và điều khoản.

Không chấp nhận:
- Tài liệu chỉ cùng lĩnh vực nhưng nói về vấn đề khác.
- Điều luật về phạt vi phạm dùng làm chứng cứ cho lãi chậm trả.
- Quy định về hợp đồng lao động dùng cho hợp đồng thương mại
  khi chưa chứng minh được tính áp dụng.
- Tiêu đề hoặc đoạn trích không đủ để xác định tính liên quan.
- Tài liệu chỉ nhắc đến vấn đề mà không có căn cứ hỗ trợ.

Không suy đoán nội dung bị thiếu. Nếu không chắc chắn,
hãy loại tài liệu đó.

Trả về JSON duy nhất:
{
  "relevant_indices": [0],
  "reasoning": "Giải thích ngắn gọn"
}

relevant_indices chỉ chứa index của tài liệu thực sự liên quan.
Nếu không có tài liệu phù hợp, trả về [].
"""

    user_prompt = f"""
RỦI RO CẦN XÁC MINH:
Loại rủi ro: {candidate.risk_type}
Mô tả: {candidate.description}

NỘI DUNG ĐIỀU KHOẢN HỢP ĐỒNG:
{contract_text[:6000]}

CÁC TÀI LIỆU PHÁP LUẬT:
{json.dumps(legal_documents, ensure_ascii=False)}

Hãy đánh giá riêng từng tài liệu và chỉ chọn tài liệu
có căn cứ nội dung trực tiếp liên quan đến rủi ro.
"""

    try:
        raw = call_llm(
            system_prompt,
            user_prompt,
            response_format={"type": "json_object"},
        )
        result = parse_json(raw)

        indices = result.get("relevant_indices", [])

        if not isinstance(indices, list):
            return []

        valid_indices = {
            i for i in indices
            if isinstance(i, int)
            and not isinstance(i, bool)
            and 0 <= i < len(references)
        }

        return [
            ref
            for i, ref in enumerate(references)
            if i in valid_indices
        ]

    except Exception:
        logger.exception(
            "Không thể kiểm tra tính liên quan của chứng cứ cho %s",
            candidate.candidate_id,
        )
        # Không xác minh được thì không giữ ứng viên.
        return []



def _is_allowed_legal_url(url: str) -> bool:
    """Chỉ chấp nhận URL thuộc chinhphu.vn hoặc thuvienphapluat.vn."""

    from urllib.parse import urlparse

    hostname = (urlparse(url).hostname or "").lower().rstrip(".")

    return any(
        hostname == domain or hostname.endswith("." + domain)
        for domain in ALLOWED_LEGAL_DOMAINS
    )


def run_agent_3(
    candidates: list[MergedRiskCandidate],
    contract_chunks: list[ContractChunk],
    trace: list[dict[str, Any]] | None = None,
) -> list[VerifiedRisk]:
    """Tách mỗi candidate thành subissue rồi xác minh độc lập từng vấn đề."""

    verified: list[VerifiedRisk] = []

    for candidate in candidates:
        subissues = split_candidate_into_legal_subissues(
            candidate=candidate,
            contract_chunks=contract_chunks,
        )
        logger.info(
            "Agent 3 tách %s thành %d vấn đề pháp lý độc lập.",
            candidate.candidate_id,
            len(subissues),
        )

        for subcandidate, preferred_queries in subissues:
            logger.info(
                "Xác minh %s | risk_type=%s | query=%s",
                subcandidate.candidate_id,
                subcandidate.risk_type,
                preferred_queries[0] if preferred_queries else subcandidate.legal_question,
            )
            try:
                result = run_agent_3_issue(
                    candidate=subcandidate,
                    contract_chunks=contract_chunks,
                    trace=trace,
                    preferred_queries=preferred_queries,
                )
            except Exception:
                logger.exception(
                    "Không thể xác minh subissue %s",
                    subcandidate.candidate_id,
                )
                continue

            if result is not None:
                verified.append(result)

    return verified
