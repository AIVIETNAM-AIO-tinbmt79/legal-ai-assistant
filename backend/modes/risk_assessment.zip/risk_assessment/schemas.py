
from typing import Literal, TypedDict

from pydantic import BaseModel, ConfigDict, Field


# ============================================================
# COMMON TYPES
# ============================================================

RiskLevel = Literal["low", "medium", "high"]
AgentName = Literal["agent_1", "agent_2"]
EvidenceType = Literal[
    "direct_contradictory",
    "direct_supportive",
    "related_not_applicable",
    "insufficient",
]


class SchemaModel(BaseModel):
    """Base schema: không chấp nhận các trường ngoài thiết kế."""

    model_config = ConfigDict(extra="forbid")


# ============================================================
# CONTRACT INPUT
# ============================================================

class ContractChunk(SchemaModel):
    """Một phần nội dung hợp đồng cần được phân tích."""

    id: str
    text: str
    article: str | None = None
    clause: str | None = None
    point: str | None = None
    hierarchy_path: str | None = None
    chunk_type: str = "unknown"
    parent_chunk_id: str | None = None


# ============================================================
# AGENT 1 / AGENT 2: RISK DETECTION
# ============================================================

class RiskSubIssue(SchemaModel):
    """Một vấn đề pháp lý con được tách sơ bộ bởi Agent 1/2."""

    risk_type: str
    description: str
    legal_question: str
    search_queries: list[str] = Field(default_factory=list)


class RiskCandidate(SchemaModel):
    """Một nhóm rủi ro được phát hiện từ một chunk."""

    chunk_id: str
    risk_type: str
    description: str
    severity: RiskLevel
    reason: str
    # Nếu không có subissues, bước merge dùng risk cha.
    subissues: list[RiskSubIssue] = Field(default_factory=list)


class AgentAnalysisResult(SchemaModel):
    """Kết quả của một Agent trên một batch hợp đồng."""

    agent: AgentName
    batch_id: str
    risks: list[RiskCandidate] = Field(default_factory=list)


# ============================================================
# MERGED RISK CANDIDATES
# ============================================================

class MergedRiskCandidate(SchemaModel):
    """Ứng viên pháp lý độc lập sau khi gộp Agent 1 và Agent 2."""

    candidate_id: str
    risk_type: str
    description: str
    related_chunk_ids: list[str] = Field(min_length=1)
    severity: RiskLevel
    reasons: list[str] = Field(default_factory=list)
    detected_by: list[AgentName] = Field(min_length=1)
    legal_question: str
    # Truy vấn cụ thể do Agent 1/2 đề xuất, Agent 3 dùng trước tiên.
    search_queries: list[str] = Field(default_factory=list)


# ============================================================
# WEB LEGAL SEARCH
# ============================================================

class LegalSearchRequest(SchemaModel):
    """Yêu cầu tìm căn cứ pháp luật trên web."""

    query: str = Field(min_length=1)
    allowed_domains: list[str] = Field(
        default_factory=lambda: ["chinhphu.vn", "thuvienphapluat.vn"]
    )
    max_results: int = Field(default=5, ge=1, le=10)


class LegalReference(SchemaModel):
    """Một kết quả pháp luật lấy từ nguồn web."""

    title: str
    url: str
    snippet: str = ""
    content: str = ""
    domain: str = ""
    published_date: str | None = None
    effective_date: str | None = None
    is_official_source: bool = False


class LegalSearchResult(SchemaModel):
    """Kết quả trả về từ công cụ tìm kiếm web."""

    query: str
    references: list[LegalReference] = Field(default_factory=list)
    search_count: int = 0
    errors: list[str] = Field(default_factory=list)


# ============================================================
# AGENT 3: LEGAL VERIFICATION
# ============================================================

class Agent3Decision(SchemaModel):
    """Quyết định của Agent 3 sau khi đọc ứng viên và bằng chứng."""

    action: Literal["search_legal", "keep", "drop", "final"]
    reasoning: str
    search_request: LegalSearchRequest | None = None
    evidence_type: EvidenceType = "insufficient"
    confidence: RiskLevel = "low"
    analysis: str = ""
    conclusion: str = ""


class VerifiedRisk(SchemaModel):
    """Một ứng viên đã qua bước đối chiếu pháp luật."""

    candidate_id: str
    risk_type: str
    description: str
    contract_chunk_ids: list[str] = Field(min_length=1)
    severity: RiskLevel
    legal_references: list[LegalReference] = Field(min_length=1)
    evidence_type: Literal["direct_contradictory"]
    confidence: RiskLevel
    analysis: str
    conclusion: str


# ============================================================
# FINAL ASSESSMENT
# ============================================================

class FinalRiskAssessment(SchemaModel):
    """Kết quả cuối cùng trả về cho người dùng."""

    risk_level: RiskLevel
    summary: str
    issues: list[VerifiedRisk] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)


# ============================================================
# AGENT TRACE
# ============================================================

class AgentTrace(SchemaModel):
    """Thông tin phục vụ theo dõi quá trình xử lý."""

    step: int
    action: str
    reasoning: str = ""
    candidate_id: str | None = None
    tool_query: str | None = None
    references_found: int = 0


# ============================================================
# WORKFLOW STATE
# ============================================================

class RiskAssessmentState(TypedDict, total=False):
    chunks: list[ContractChunk]
    contract_summary: str
    batches: list[list[ContractChunk]]
    agent_1_results: list[AgentAnalysisResult]
    agent_2_results: list[AgentAnalysisResult]
    candidate_issues: list[MergedRiskCandidate]
    verified_issues: list[VerifiedRisk]
    agent_trace: list[AgentTrace]
    agent3_tool_calls: int
    final_assessment: FinalRiskAssessment


class LegalWebResult(BaseModel):
    """Một kết quả tìm kiếm web từ Tavily."""

    title: str = ""
    url: str = ""
    content: str = ""
    score: float = 0.0
    source_domain: str = ""


class LegalToolResult(BaseModel):
    """Kết quả trả về từ công cụ tìm kiếm pháp luật."""

    query: str = ""
    references: list = Field(default_factory=list)
    search_results: list[LegalWebResult] = Field(default_factory=list)
    search_count: int = 0
    errors: list[str] = Field(default_factory=list)
