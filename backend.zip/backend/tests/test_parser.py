from pathlib import Path 
from parser.pdf_parser import PDFParser
from parser.parser_factory import ParserFactory
from chunking.chunker_factory import ChunkerFactory
from parser.cleaner import TextCleaner

path_file = Path(r"D:\legal-ai-assistant\backend\data\sample_contracts\docx_test.docx")
parser = ParserFactory.get_parser(path_file)
text = parser.parse(path_file)

text = TextCleaner.clean(text)
chunker = ChunkerFactory.create(text)

print("=" * 70)
print("CHUNKER:", type(chunker).__name__)
print("=" * 70)


# ==============================
# Chunk document
# ==============================

chunks = chunker.chunk(text)


# ==============================
# Display chunks
# ==============================

for i, chunk in enumerate(chunks, start=1):

    print()
    print("=" * 70)
    print(f"CHUNK {i}")
    print("=" * 70)

    print("ID:", chunk.id)

    print("\nMETADATA:")
    print(chunk.metadata)

    print("\nTEXT:")
    print("-" * 70)
    print(chunk.text)
    print("-" * 70)