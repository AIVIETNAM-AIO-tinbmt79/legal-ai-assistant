from retrieval.retriever_factory import RetrieverFactory


# ==================================================
# CONFIG
# ==================================================

QUERY = (
    "Bên A có nghĩa vụ "
    "thanh toán cho Bên B"
)

HYBRID_TOP_K = 5
RETRIEVAL_K = 20


# ==================================================
# Create Hybrid Retriever
# ==================================================

retriever = RetrieverFactory.create(
    retriever_type="hybrid",

    top_k=HYBRID_TOP_K,

    retrieval_k=RETRIEVAL_K,

    semantic_weight=0.7,

    bm25_weight=0.3,
)


# ==================================================
# Retrieve
# ==================================================

results = retriever.retrieve(
    query=QUERY,
    top_k=HYBRID_TOP_K,
)


# ==================================================
# Display
# ==================================================

print()
print("=" * 70)
print("HYBRID RETRIEVAL")
print("=" * 70)

print("Query:")
print(QUERY)

print()

print("Results:")
print(len(results))


for rank, result in enumerate(
    results,
    start=1,
):

    print()
    print("-" * 70)

    print("RANK:")
    print(rank)

    print("SCORE:")
    print(result.score)

    print("SOURCE:")
    print(result.source)

    print("CHUNK ID:")
    print(result.chunk.id)

    print("METADATA:")
    print(result.chunk.metadata)

    print()
    print("TEXT:")
    print(result.chunk.text)